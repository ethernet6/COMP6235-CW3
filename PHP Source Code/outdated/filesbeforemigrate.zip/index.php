

<form action="calculate.php" method="post">

<select name="carform">
  <option value="BMW 328d">BMW 328d</option>
  <option value="AUDI A4 Ultra">AUDI A4 Ultra</option>
</select>

<input type="submit" name="name">
</form>