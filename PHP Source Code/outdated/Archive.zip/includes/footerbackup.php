<!--footer start-->

        <div id="cont-footer">
      <footer class="container white">
        <div class="row">
          <div class="grid-third">
            <h4>About us</h4>
            <p>
              Improved fuel economy saves you money every time you fill up!
            </p>
          </div>          
          <div class="grid-third">
            <h4>Content Delivery Networks</h4>
            <div class="row">
              <div class="grid-half">
                <ul class="list-unstyled white">
                    
                  <li><a href="#">Find a Car</a></li>
            <li><a href="/guides/">Save Money & Fuel</a></li>
            <li><a href="/tools/">Benefits</a></li>
            <li><a href="/blog/">My MPG</a></li>
			<li><a href="/blog/">Advanced Cars & Fuels</a></li>
			<li><a href="/blog/">About EPA Ratings</a></li>
                   
                </ul>
              </div>
              <div class="grid-half">
                <ul class="list-unstyled white">
                     
                  <li><a href="#">Find a Car</a></li>
            <li><a href="/guides/">Save Money & Fuel</a></li>
            <li><a href="/tools/">Benefits</a></li>
            <li><a href="/blog/">My MPG</a></li>
			<li><a href="/blog/">Advanced Cars & Fuels</a></li>
			<li><a href="/blog/">About EPA Ratings</a></li>
                  
                </ul>
              </div>
            </div>
          </div>
          <div class="grid-third">
            <h4>Vehicle Blog</h4>
            <ul>
              
              <li><a href="#">Find a Car</a></li>
            <li><a href="/guides/">Save Money & Fuel</a></li>
            <li><a href="/tools/">Benefits</a></li>
            <li><a href="/blog/">My MPG</a></li>
			<li><a href="/blog/">Advanced Cars & Fuels</a></li>
			<li><a href="/blog/">About EPA Ratings</a></li>
              
            </ul>
          </div>
        </div>
      </footer>
    </div>



    <div>
      <div class="container gray padding-top-small">
        <ul class="list-inline margin-bottom-small gray">
          <li><small>© 2011-2017 All rights reserved.</small></li>
          <!--<li><small> <a href="http://www.turbobytes.com/">TurboBytes</a></small></li>-->
        </ul>
      </div>
    </div>
	<!--footer ends-->
</body>
</html>