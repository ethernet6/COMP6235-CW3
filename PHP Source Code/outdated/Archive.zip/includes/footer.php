<!--footer start-->

        <div id="cont-footer">
      <footer class="container white">
        <div class="row">
          <div class="grid-third">
            <h4>About us</h4>
            <p>
            This is web app for the group "404 Group Not Found" which is a requirement in CW3 in "COMP6235 - Foundations of Data Science".


            </p>
          </div>          
         
          <div class="grid-third">
            <h4>Contact Us</h4>
              
              <a href="mailto:gc7g17@soton.ac.uk">Send an email </a>
              
          </div>
        </div>
      </footer>
    </div>



    <div>
      <div class="container gray padding-top-small">
        <ul class="list-inline margin-bottom-small gray">
          <li><small>© 2018 - 404 Group Not Found - All rights reserved.</small></li>
          <!--<li><small> <a href="http://www.turbobytes.com/">TurboBytes</a></small></li>-->
        </ul>
      </div>
    </div>
	<!--footer ends-->
</body>
</html>